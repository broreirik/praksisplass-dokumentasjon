// Praksisplass service worker.
// Skallet forhåndslagres. HTML hentes nettverk-først, data/*.json stale-while-revalidate,
// ikoner cache-først. Alt annet nettverk-først med mellomlager som reserve.
const V = "v7";
const SKALL = "praksis-skall-" + V;
const DATA = "praksis-data-" + V;
const MAKS_K = 6; // antall fylkesfiler (data/fylker) vi beholder; 80 km rundt en skole dekker sjelden mer enn 3-4 fylker
const FORHAND = [
  "./", "index.html", "manifest.webmanifest",
  "ikon/192.png", "ikon/512.png", "ikon/apple-180.png", "ikon/maskable-512.png",
  "personvern.html", "vilkar.html",
];
const OFFLINE = "<!doctype html><html lang=\"nb\"><head><meta charset=\"utf-8\"><meta name=\"viewport\" content=\"width=device-width, initial-scale=1\"><title>Uten nett</title></head><body style=\"font:16px/1.6 system-ui,sans-serif;max-width:40rem;margin:2rem auto;padding:0 1rem\"><h1>Du er uten nett</h1><p>Denne siden er ikke lagret på enheten ennå. Koble til nett og prøv igjen.</p></body></html>";

const offlineSide = () => new Response(OFFLINE, { status: 503, headers: { "Content-Type": "text/html; charset=utf-8" } });
const offlineTekst = () => new Response("Uten nett og ikke lagret på enheten.", { status: 503, headers: { "Content-Type": "text/plain; charset=utf-8" } });

self.addEventListener("install", (e) => {
  e.waitUntil(
    caches.open(SKALL).then((c) =>
      // én og én, så en manglende fil ikke stopper hele installasjonen
      Promise.all(FORHAND.map((u) => c.add(new Request(u, { cache: "reload" })).catch(() => {})))
    ).then(() => self.skipWaiting())
  );
});

self.addEventListener("activate", (e) => {
  e.waitUntil(
    caches.keys()
      .then((ks) => Promise.all(ks.filter((k) => k.startsWith("praksis-") && k !== SKALL && k !== DATA).map((k) => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});

self.addEventListener("message", (e) => {
  if (e.data && e.data.type === "SKIP_WAITING") self.skipWaiting();
});

async function lagre(navn, req, res, maks) {
  const c = await caches.open(navn);
  await c.delete(req); // legges bakerst, så eldste ligger først
  await c.put(req, res);
  if (maks) {
    const ks = await c.keys();
    const k = ks.filter((r) => new URL(r.url).pathname.includes("/data/fylker/"));
    await Promise.all(k.slice(0, Math.max(0, k.length - maks)).map((r) => c.delete(r)));
  }
}

const ok = (r) => r && r.status === 200;

async function nettFørst(req, navn, navigasjon) {
  try {
    const r = await fetch(req);
    if (ok(r) && !new URL(req.url).search) { const k = r.clone(); lagre(navn, req, k).catch(() => {}); }
    return r;
  } catch (_) {
    const m = (await caches.match(req)) || (await caches.match(req, { ignoreSearch: true }));
    if (m) return m;
    if (navigasjon) return (await caches.match("index.html")) || offlineSide();
    return offlineTekst();
  }
}

async function dataSWR(req) {
  const treff = await caches.match(req);
  const nett = fetch(req).then((r) => {
    if (ok(r)) {
      const k = r.clone();
      lagre(DATA, req, k, MAKS_K).catch(() => {});
    }
    return r;
  });
  if (treff) { nett.catch(() => {}); return treff; }
  try { return await nett; } catch (_) { return offlineTekst(); }
}

async function cacheFørst(req) {
  const m = await caches.match(req);
  if (m) return m;
  try {
    const r = await fetch(req);
    if (ok(r)) { const k = r.clone(); lagre(SKALL, req, k).catch(() => {}); }
    return r;
  } catch (_) {
    return offlineTekst();
  }
}

self.addEventListener("fetch", (e) => {
  const req = e.request;
  const u = new URL(req.url);
  if (req.method !== "GET" || u.origin !== location.origin || req.headers.has("range")) return;
  const sti = u.pathname;
  if (/\/data\/(k\/)?[^/]+\.json$/.test(sti)) return e.respondWith(dataSWR(req));
  if (/\/ikon\//.test(sti)) return e.respondWith(cacheFørst(req));
  if (/\/n\/[0-9a-f]{12}\./.test(sti)) return; // bilder og tekst fra nettsidene: vanlig nettlesercache, ikke SW
  const html = req.mode === "navigate" || req.destination === "document" || sti.endsWith(".html") || sti.endsWith("/");
  e.respondWith(nettFørst(req, SKALL, html));
});
